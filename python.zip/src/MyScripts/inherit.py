﻿from Rectangle import *
from Triangle import *

rect = Rectangle()
trey = Triangle()

rect.set_values( 4 , 5 )
trey.set_values( 4 , 5 )

print( 'Rectangle Area:' , rect.area() )
print( 'Triangle Area:' , trey.area() ) 