﻿import cat

pet = input( 'Enter A Pet Name: ' )

cat.purr( pet )
cat.lick( pet )
cat.nap( pet )
