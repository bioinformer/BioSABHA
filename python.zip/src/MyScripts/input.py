﻿# Initialize a variable with a user-specified value.
user = input( 'I am Python. What is your name? : ' )

# Output a string and a variable value.
print( 'Welcome' , user )

# Initialize another variable with a user-specified value.
lang = input( 'Favorite programming language? : ' )

# Output a string and a variable value.
print( lang , 'Is' , 'Fun' , sep = ' * ' , end = '!\n' )
