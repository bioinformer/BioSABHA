﻿import cat

cat.purr()
cat.lick()
cat.nap()

cat.purr( 'Kitty' )
cat.lick( 'Kitty' )
cat.nap( 'Kitty' )
