﻿from dog import *

pet = input( 'Enter A Pet Name: ' )

bark( pet )
lick( pet )
nap( pet )



