﻿nil = 0
num = 0
max = 1
cap = 'A'
low = 'a'

print( 'Equality :\t' , nil , '==' , num , nil == num )
print( 'Equality :\t' , cap , '==' , low , cap == low )
print( 'Inequality :\t' , nil , '!=' , max , nil != max )

print( 'Greater :\t' , nil , '>' , max , nil > max )
print( 'Lesser :\t' , nil , '<' , max , nil < max )

print( 'More Or Equal :\t' , nil , '>=' , num , nil >= num )
print( 'Less or Equal :\t' , max , '<=' , num , max <= num )