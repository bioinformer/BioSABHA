﻿a = True
b = False

print( 'AND Logic:' )
print( 'a and a =' , a and a )
print( 'a and b =' , a and b )
print( 'b and b =' , b and b )

print( '\nOR Logic:' )
print( 'a or a =' , a or a )
print( 'a or b =' , a or b )
print( 'b or b =' , b or b )

print( '\nNOT Logic:' )
print( 'a =' , a , '\tnot a =' , not a )
print( 'b =' , b , '\tnot b =' , not b )