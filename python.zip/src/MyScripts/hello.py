﻿print( 'Hello World!' ) 
