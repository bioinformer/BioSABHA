﻿print( 'Python in easy steps  )
