a = 8
b = 2

print( 'Addition:\t' , a , '+', b , '=' , a + b )

print( 'Subtraction:\t' , a , '-', b , '=' , a - b )

print( 'Multiplication:\t' , a , 'x', b , '=' , a * b )

print( 'Division:\t' , a , '÷', b , '=' , a / b )
print( 'Floor Division:\t' , a , '÷', b , '=' , a // b )

print( 'Modulo:\t\t' , a , '%', b , '=' , a % b )
 
print( 'Exponent:\t ' , a , '² = ' , a ** b , sep = '' )


