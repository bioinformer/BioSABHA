﻿class Duck :

	'''A class to define Duck properties.'''

	def talk( self ) :
		print( '\nDuck Says: Quack!' )

	def coat( self ) :
		print( 'Duck Wears: Feathers' )
